#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace::std;

enum enMainMenu{QuickWithdraw = 1,NormalWithdraw = 2,Deposit = 3,ChickBalance = 4,Logout = 5};
enum enQuickdraw{one = 20,tow =50,thrie = 100,fore = 200,five = 400,six = 600,sevin = 800,aete = 1000,Exit};

const string failName = "Client.txt";
void ATM_MainMenuScreen();
void MainMenuOption(enMainMenu MainMenu);

struct stClient
{
	string AccountNumber;
	string ClientName;
	string pincod;
	string phone;
	double Balance;
	bool MarkforDelet = false;

};

void GobackMainMenu()
{
	cout << "\n\npress any key to go back main menu......";
	system("pause > 0");
	ATM_MainMenuScreen();
}

vector<string> Split(string line,string Demeleter)
{
	vector<string>vstring;
	string word = "";
	short pos = 0;

	while ((pos = line.find(Demeleter)) != std::string::npos)
	{
		word = line.substr(0, pos);

		if (word != " ")
		{
		   vstring.push_back(word);
		}
		line.erase(0, pos + Demeleter.length());
	}
	if (line != " ")
	{
		vstring.push_back(line);
	}
	return vstring;
}
stClient ConvertDataToRecord(string line, string separeter = "#//#")
{
	stClient Client;

	vector<string> vclient = Split(line, separeter);

	Client.AccountNumber = vclient[0];
	Client.pincod = vclient[1];
	Client.ClientName = vclient[2];
	Client.phone = vclient[3];
	Client.Balance = stod(vclient[4]);

	return Client;
}
string ConvertRecordToLine(stClient client, string separeter = "#//#")
{
	
	string line = "";

	line += client.AccountNumber + separeter;
	line += client.pincod + separeter;
	line += client.ClientName + separeter;
	line += client.phone + separeter;
	line += to_string(client.Balance);

	return line;
}
vector<stClient>LoadDataFromFile(string failname)
{
	vector < stClient > vclient;
	fstream myfail;

	myfail.open(failname,ios::in);

	if (myfail.is_open())
	{
		string line;
		stClient clinet;

		while (getline(myfail,line))
		{
			clinet = ConvertDataToRecord(line);
			vclient.push_back(clinet);
		}
		myfail.close();
	}
	return vclient;
}
vector<stClient>SaveDataToFaile(string failname, vector<stClient> vclient)
{
	fstream Myfile;

	Myfile.open(failname, ios::out );
	string line;

	if (Myfile.is_open())
	{
		for (stClient c : vclient)
		{
			
				line = ConvertRecordToLine(c);
				Myfile << line << endl;
			
		}
		Myfile.close();
	}
	return vclient;
}

string ReadAccountNumber()
{
	string AccountNumber;
	cin >> AccountNumber;
	return AccountNumber;
}
string ReadPinCode()
{
	string Pincode;
	cin >> Pincode;
	return Pincode;
}
short Readnumber()
{
	short num = 0;
	cout << "choose what do you want to do? [1 to 5] ? ";
	cin >> num;
	return num;
}
short ReadQuicknumber()
{
	short num = 0;
	cin >> num;
	return num;
}
short ReadMultipleOf5()
{
	short num = 0;
	do
	{
		cout << "Enter an mount multiple of 5's ? ";
		cin >> num;
		if (num % 5 == 0)
		{
			return num;
		}

	} while (true);
	
}

stClient Client;

void BalanceChick(vector<stClient>vclient)
{
	string Accountnumber = Client.AccountNumber;
	for (stClient& c : vclient)
	{
		if (c.AccountNumber == Accountnumber)
		{
			 cout << c.Balance;
		}
	}

}

short QuickWithdrawCalculate(short num )
{
	
	if (num == 1)
	{
		return  20;
	}
	else if (num == 2)
	{
		return 50;
	}
	else if (num == 3)
	{
		return 100;
	}
	else if (num == 4)
	{
		return 200;
	}
	else if (num == 5)
	{
		return 400;
	}
	else if (num == 6)
	{
		return 600;
	}
	else if (num == 7)
	{
		return 800;
	}
	else if (num == 8)
	{
		return 1000;
	}
	else if (num == 9)
	{
	   GobackMainMenu();
	}
	
}
bool NormalwithdrawCalculat(vector<stClient>& vclient)
{
	stClient client;

	char Answer = 'y';
	double amount = 0;
	string AccountNumber = Client.AccountNumber;

	amount = ReadMultipleOf5();
	cout << "Are You sure you want perfrom this transaction ? Y/N ? ";
	cin >> Answer;


	if (Answer == 'y'||Answer == 'Y')
	{
		for (stClient& c : vclient)
		{
			if (c.AccountNumber == AccountNumber)
			{
				if (c.Balance < amount)
				{
					cout << "The amount exceeds your balance, make another choice.\n";
					return false;
				}

				c.Balance += amount * -1;
				break;
			}

		}
		SaveDataToFaile(failName, vclient);
		vclient = LoadDataFromFile(failName);
		cout << "Done succissfully. New balance is : " << Client.Balance -amount;
		return true;
	}
	else
	{
		return false;
	}

	

	
}
bool QuickwithdrawCalculat1(vector<stClient>& vclient)
{
	stClient client;

	char Answer = 'y';
	double amount = 0;
	string AccountNumber = Client.AccountNumber;

	amount = ReadQuicknumber();
	double QuickNum = QuickWithdrawCalculate(amount);
	cout << "Are You sure you want perfrom this transaction ? Y/N ? ";
	cin >> Answer;


	if (Answer == 'y' || Answer == 'Y')
	{
		for (stClient& c : vclient)
		{
			if (c.AccountNumber == AccountNumber)
			{
				if (c.Balance < QuickNum)
				{
					cout << "The amount exceeds your balance, make another choice.\n";
					return false;
				}

				c.Balance += QuickNum * -1;
				break;
			}

		}
		SaveDataToFaile(failName, vclient);
		vclient = LoadDataFromFile(failName);
		cout << "Done succissfully. New balance is :  "; 
		BalanceChick(vclient);

		return true;
	}
	else
	{
		return false;
	}




}
bool DepositCalculat(vector<stClient>& vclient)
{
	stClient client;

	char Answer = 'y';
	double amount = 0;
	string AccountNumber = Client.AccountNumber;

	cout << " Enter a positive Deposit Amount ? ";
	cin >> amount;
	
	cout << "Are You sure you want perfrom this transaction ? Y/N ? ";
	cin >> Answer;


	if (Answer == 'y' || Answer == 'Y')
	{
		for (stClient& c : vclient)
		{
			if (c.AccountNumber == AccountNumber)
			{

				c.Balance += amount * +1;
				break;
			}

		}
		SaveDataToFaile(failName, vclient);
		vclient = LoadDataFromFile(failName);
		cout << "Done succissfully. New balance is :  "; 
		BalanceChick(vclient);

		return true;
	}
	else
	{
		return false;
	}




}
bool chickAccountNumberAndPinCode(stClient& client,string Accountnumber,string pincode)
{
	vector<stClient> vclient = LoadDataFromFile(failName);

	for (stClient c : vclient)
	{
		if (c.AccountNumber == Accountnumber && c.pincod == pincode)
		{
			client = c;
			return true;
		}
	}
	return false;
}
bool LoadClientInfo(string AccountNumber, string Pincode)
{
	if (chickAccountNumberAndPinCode(Client,AccountNumber,Pincode))
		return true;
	else
		return false;

}
bool findClientByAccountNumber(vector<stClient>vclient,string AccountNumber,stClient& Client)
{
	for (stClient c : vclient)
	{
		if (c.AccountNumber == AccountNumber)
		{
			Client = c;
			return true;
		}

	}
	return false;
}

void ATM_MainMenuScreen()
{
	system("cls");
	cout << "======================================================\n";
	cout << "\t\tAtm Main Menue Screen         \n";
	cout << "======================================================\n";
	cout << "\t[1] Quick Withdraw.\n";
	cout << "\t[2] Normal Withdraw.\n";
	cout << "\t[3] Deposit.\n";
	cout << "\t[4] Chick Balance.\n";
	cout << "\t[5] Logout.\n";
	cout << "======================================================\n";
	MainMenuOption((enMainMenu)Readnumber());

}
void QuickWithdrawScreen()
{
	char Withdraw = 'y';
	system("cls");
	cout << "======================================================\n";
	cout << "\t\tQuick Withdraw         \n";
	cout << "======================================================\n";
	cout << "\t[1] 20 \t";
	cout << "\t[2] 50\n";
	cout << "\t[3] 100\t";
	cout << "\t[4] 200\n";
	cout << "\t[5] 400\t";
	cout << "\t[6] 600\n";
	cout << "\t[7] 800\t";
	cout << "\t[8] 1000\n";
	cout << "\t[9] Exit\n";
	cout << "======================================================\n";
	vector<stClient>vclient = LoadDataFromFile(failName);
	cout << "Your balance is : ";
	BalanceChick(vclient);

	cout << "\nChoose what to withdraw from [1] to [8] ? \n\n";
	QuickwithdrawCalculat1(vclient);
	
		GobackMainMenu();
	

}
void NormalWithdrawScreen()
{
	system("cls");
	cout << "======================================================\n";
	cout << "\t\tNormal Withdraw Screen         \n";
	cout << "======================================================\n";
	vector<stClient>vClient = LoadDataFromFile(failName);
	
	
	//UpdateClientByAccountNumber(Client.AccountNumber, vClient, num);
	NormalwithdrawCalculat(vClient);
	

}
void ChickBalanceScreen()
{
	system("cls");
	cout << "======================================================\n";
	cout << "\t\tChick Balance Screen         \n";
	cout << "======================================================\n";
	vector<stClient> vclient = LoadDataFromFile(failName);

	cout << "Your balance is : ";
	BalanceChick(vclient);
	

}
void DepositScreen()
{
	system("cls");
	cout << "======================================================\n";
	cout << "\t\tDeposit Screen         \n";
	cout << "======================================================\n";
	vector<stClient>vclient = LoadDataFromFile(failName);

	DepositCalculat(vclient);
}
void LoginScreen()
{
	system("cls");

	cout << "======================================================\n";
	cout << "\t\tLogin Screen         \n";
	cout << "======================================================\n";

}
void Login()
{
	stClient client;
	bool IsFaild = false;
	
	string AccountNumber, Pincode;

	do
	{
		system("cls");
		LoginScreen();
		if (IsFaild)
		{
			cout << "Invlaid Account number / Pincode! \n";
		}
		cout << "Enter Account Number? ";
		AccountNumber = ReadAccountNumber();
		cout << "Enter Pin? ";
		Pincode = ReadPinCode();
		IsFaild = !LoadClientInfo(AccountNumber, Pincode);

	} while (IsFaild);
	ATM_MainMenuScreen();

}

void MainMenuOption(enMainMenu MainMenu)
{
	switch (MainMenu)
	{
	case QuickWithdraw:
		system("cls");
		QuickWithdrawScreen();
		GobackMainMenu();
		break;
	case NormalWithdraw:
		system("cls");
		NormalWithdrawScreen();
		GobackMainMenu();
		break;
	case Deposit:
		system("cls");
		DepositScreen();
		GobackMainMenu();
		break;
	case ChickBalance:
		system("cls");
		ChickBalanceScreen();
		GobackMainMenu();
		break;
	case Logout:
		system("cls");
		Login();
		break;
	}
}

int main()
{
	Login();
	
	system("pause >0");

	return 0;
}


